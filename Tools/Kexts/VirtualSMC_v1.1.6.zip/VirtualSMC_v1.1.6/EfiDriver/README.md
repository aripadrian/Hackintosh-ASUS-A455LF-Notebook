VirtualSmc.efi
==============

Legacy driver for bootloaders and firmwares without VirtualSMC support. Source code
is located in [AppleSupportPkg](https://github.com/acidanthera/AppleSupportPkg/tree/d7ea839) repo.
Last sync with AppleSupportPkg: b7083cd7d0f07a489b8692469184cd21bc7d1d68

Reference implementation for bootloader implementation is provided by OcSmcLib in
[OcSupportPkg](https://github.com/acidanthera/OcSupportPkg) repo.
